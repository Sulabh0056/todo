import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import TaskManager from './component/task1'
import "./styles/style.css"

function App() {
  return (
    <>
     <TaskManager/>
    </>
  )
}

export default App
